// Java utilities packages
import java.math.BigInteger;
import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Pattern;
import java.io.*;
// Packages for graphics
import javax.swing.*;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.event.*;
import java.awt.*;
// Unicrypt library imports
import ch.bfh.unicrypt.math.algebra.concatenative.classes.StringMonoid;
import ch.bfh.unicrypt.math.algebra.dualistic.classes.*;
import ch.bfh.unicrypt.math.algebra.general.classes.*;
import ch.bfh.unicrypt.math.algebra.multiplicative.classes.*;
import ch.bfh.unicrypt.crypto.schemes.encryption.classes.ElGamalEncryptionScheme;
import ch.bfh.unicrypt.crypto.schemes.signature.classes.SchnorrSignatureScheme;
import ch.bfh.unicrypt.crypto.proofsystem.challengegenerator.classes.FiatShamirSigmaChallengeGenerator;
import ch.bfh.unicrypt.crypto.proofsystem.challengegenerator.interfaces.SigmaChallengeGenerator;
import ch.bfh.unicrypt.crypto.proofsystem.classes.ElGamalEncryptionValidityProofSystem;
import ch.bfh.unicrypt.helper.math.Alphabet;
import ch.bfh.unicrypt.helper.prime.SafePrime;

/**
 * Main class of the project. It initializes the application and starts the execution.
 */
class Application extends JFrame implements ActionListener {

    // ---------- GUI Objects definition ----------

    // Frame that contains GUI elements
    static JFrame frame = new JFrame("SecureSurvey");
    // Panels
    static JPanel loginPanel = new JPanel();
    static JPanel signupPanel = new JPanel();
    static JPanel researcherMainPanel = new JPanel();
    static JPanel researcherSurveysPanel = new JPanel();
    static JScrollPane researcherScrollPane = new JScrollPane();
    static JPanel newsurveyPanel = new JPanel();
    static JPanel voterMainPanel = new JPanel();
    static JPanel voterSurveysPanel = new JPanel();
    static JScrollPane voterScrollPane = new JScrollPane();
    static JPanel votePanel = new JPanel();
    // Events handler
    static Application ct = new Application();
    // GUI objects
    static JLabel loginLabel = new JLabel("Login");
    static JLabel usernameLabel = new JLabel("Username:");
    static JTextField usernameField = new JTextField();
    static JLabel passwordLabel = new JLabel("Password:");
    static JPasswordField passwordField = new JPasswordField();
    static JButton loginButton = new JButton("LOGIN");
    static JButton signupButton = new JButton("SIGN UP");
    static JLabel errorLabel = new JLabel("<html>The credentials could not be found. <br/>Please try again.</html>");
    static JLabel signupLabel = new JLabel("Sign up");
    static JLabel usernameLabel2 = new JLabel("Username:");
    static JTextField usernameField2 = new JTextField();
    static JLabel passwordLabel2 = new JLabel("Password:");
    static JPasswordField passwordField2 = new JPasswordField();
    static JLabel passwordLabel3 = new JLabel("Retype password:");
    static JPasswordField passwordField3 = new JPasswordField();
    static ButtonGroup buttonGroup = new ButtonGroup();
    static JRadioButton voterRadioButton = new JRadioButton("Voter");
    static JRadioButton researcherRadioButton = new JRadioButton("Researcher");
    static JButton signupButton2 = new JButton("SIGN UP");
    static JButton backtoLoginButton = new JButton("BACK");
    static JLabel errorLabel2 = new JLabel("<html>The username must contain 5 to 16 alphanumeric characters.</html>");
    static JLabel errorLabel3 = new JLabel("<html>The password must be at least 8 characters long and must contain at least one lower case letter [a-z], one upper case letter [A-Z], one number [0-9] and one special character [%=_?!@#$&*-].</html>");
    static JLabel errorLabel4 = new JLabel("<html>The passwords do not match.</html>");
    static JLabel errorLabel5 = new JLabel("<html>The username is already taken. <br/>Please try again.</html>");
    static JLabel researcherLabel = new JLabel("Researcher");
    static JLabel researcherLabel2 = new JLabel("Researcher");
    static JLabel researcherColumnLabel1 = new JLabel("Title");
    static JLabel researcherColumnLabel2 = new JLabel("Status");
    static JLabel researcherColumnLabel3 = new JLabel("<html>Results<br/>(Y N A)</html>");
    static JLabel voterLabel = new JLabel("Voter");
    static JLabel voterLabel2 = new JLabel("Voter");
    static JLabel voterColumnLabel = new JLabel("Open surveys");
    static JLabel loggedInLabel = new JLabel();
    static JLabel loggedInLabel2 = new JLabel();
    static JButton logoutButton = new JButton("LOGOUT");
    static JButton newsurveyButton = new JButton("Create a new survey");
    static JButton gobackButton = new JButton("BACK");
    static JLabel newsurveyLabel = new JLabel("Insert question:");
    static JTextArea surveyArea = new JTextArea(5, 30);
    static JButton opensurveyButton = new JButton("OPEN");
    static JLabel surveyLabel = new JLabel();
    static JButton yesButton = new JButton("YES");
    static JButton noButton = new JButton("NO");
    static JButton abstainButton = new JButton("ABSTAIN");
    // Colors
    static Color buttonColor = new Color(200,200,200);
    static Color errorColor = new Color(200, 0, 0);
    static Color firstAlternatingColor = new Color(220,220,220);
    static Color firstAlternatingColor2 = new Color(215,215,215);
    static Color secondAlternatingColor = new Color(230,230,230);
    static Color secondAlternatingColor2 = new Color(225,225,225);

    // ---------- Main Attributes definition ----------

    // Session parameters
    String username;
    ArrayList<Survey> surveys = new ArrayList<>();
    String role;
    // Server
    static Server server = new Server();
    // Public parameters of elgamal encryption scheme
    static SafePrime safePrime = SafePrime.getInstance(new BigInteger("3952952178374640418685184644643708984074546024231724208070151738783263001877343589194283126064568671556054993913274656691266608028677124594822206814448069491672998261272213051291177598337250923016919856810019580253952209989658256703161738884745447892020055216615287652194338554628287069936110145818155328604534810095424963664114705686745495305052840776143931406780841441345247291460095883322441161433418652974157438099930479228013556776925727257771826809329604326695728044527371419345492855373804942166500544215272684440967470853540597382459478160044133807079579451508796628347553496488780847406551031849198721357471657010942640269179167074415651284916184657139734636221691799957857096887845722374764751301165724816790152735442699688944209717130091135675454795867014806599819715107283855486717011212372713268157823054092934109945546052453277746770135010661472066291976636681212590319367400517427424502915017501466270244564299"));
    static GStarModSafePrime group = GStarModSafePrime.getInstance(safePrime);
    static GStarModElement generator = group.getDefaultGenerator();
    static ZMod order = generator.getSet().getZModOrder();
    static ElGamalEncryptionScheme elGamal = ElGamalEncryptionScheme.getInstance(generator);
    // Public parameters of schnorr signature scheme
    static SafePrime signSafePrime = SafePrime.getInstance(new BigInteger("5160289179960913922009630589553873386446241019346066584464789733730529820775975471558805071001746248628965281196631715655109211787623320097221593154021723397413011719734825864232550218292057819849916908621353330525916072743165961080647184413487006364873221639845813146666157485755176658930371463993970056677757245432617427952951731498672609884810444913435773165937698003676572685047604068221509587202023297212873219531499035553703317613901825962011464061665423331698093440057864951952119673263059442933268245837277755763504933073113278902151604780014211261994612488374092317481901995549233927884671313557525416210871791422878409622395862982552410160289950588703962692996276939322845431023867250713848696061595832893135813695573480799636518983135136110599909525694861264909900250864213944676652049701033110767457812408129043294318490225853306447730455615051514435305370888890407096401247663787658762826982331485609360468173807"));
    static GStarModSafePrime signGroup = GStarModSafePrime.getInstance(signSafePrime);
    static GStarModElement signGenerator = signGroup.getDefaultGenerator();
    static ZMod signOrder = signGenerator.getSet().getZModOrder();
    @SuppressWarnings("unchecked")
    static SchnorrSignatureScheme<StringMonoid> schnorr = SchnorrSignatureScheme.getInstance(StringMonoid.getInstance(Alphabet.BASE64), signGenerator);
    // Auxiliary objects
    static String regexUser = "^[a-zA-Z0-9]{5,16}$";
    static String regexPass = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[%=_?!@#$&*-]).{8,}$";

    // ---------- General methods definition ----------

    /**
     * Check for the validity of username and password during sign up, and for the
     * equality of the two passwords inserted
     *  - username: 5-16 alphanumeric characters
     *  - password: at least 8 charcaters (at least one uppercase letter, one
     *              lowercase letter, one number, one special character (%=_?!@#$&*-)
     * @param tempusername  inserted username
     * @param temppassword  inserted password
     * @param checkpassword In
     * @return an array of three boolean values: check succeeded if all the 
     *         three values are true
     */
    public boolean[] checkCredentials(String tempusername, char[] temppassword, char[] checkpassword) {
        boolean[] validity = new boolean[3];
        // Check username
        validity[0] = tempusername.matches(regexUser);
        // Check password
        validity[1] = Pattern.matches(regexPass, CharBuffer.wrap(temppassword));
        // Check that the two passwords are equal
        validity[2] = Arrays.equals(temppassword,checkpassword);
        return validity;
    }

    /**
     * An user has been created, here the personal files are created and a pair of keys
     * for the signature is generated
     * @param tempusername  inserted username
     * @param temprole  chosen role
     * @return public key of the user that will be used to verify the signature
     */
    public String createNewUser(String tempusername, String temprole){
        OutputStreamWriter osw = null;
		try{
			try{
                if (temprole.equals("voter")){
                    // Generate keys for schnorr signature scheme
                    Pair keyPair = schnorr.getKeyPairGenerator().generateKeyPair();
                    // Create the personal file
                    osw = new OutputStreamWriter(new FileOutputStream("./voters/" + tempusername + ".txt"), "UTF-8");
					osw.write(keyPair.getFirst().getValue().toString());
                    return(keyPair.getSecond().getValue().toString());
                } else {
                    // Create the personal file
                    osw = new OutputStreamWriter(new FileOutputStream("./researchers/" + tempusername + ".txt"), "UTF-8");
                    osw.write("");
                }
			}finally{
				if (osw != null) osw.close();
			}
		}catch (IOException ex) {
			// In case of reading/writing error print error on console
			System.out.println(ex);
		}
        return "";
    }
    
    /**
     * An user has voted for a survey, here the vote is encrypted and signed.
     * Moreover, two zk proofs are created: 
     * 1. the proof that each element is either 0 or 1;
     * 2. the proof that the sum of the three elements is 1.
     * @param vote cast vote, either “Yes” or “No” or “Abstain”
     * @param publicKey public key associated to the survey
     * @param signPrivateKey private key of the voter for signature
     * @return object of the class vote containing ciphertext, signature 
     *         and zero knowledge proofs
     */
    public Vote encryptVote(String vote, GStarModElement publicKey, ZModElement signPrivateKey) {
        var encodedOne = generator.selfApply(1);
        var encodedZero = generator.selfApply(0);
        var impossibleElement = generator.selfApply(4);

        // Initialization of the proof system
        var proverId = StringMonoid.getInstance(Alphabet.BASE64).getElement(username);
        SigmaChallengeGenerator challengeGenerator = FiatShamirSigmaChallengeGenerator.getInstance(group.getZModOrder(), proverId);
        Subset subset = Subset.getInstance(group, encodedZero, encodedOne);
        ElGamalEncryptionValidityProofSystem proofSystem = ElGamalEncryptionValidityProofSystem.getInstance(challengeGenerator, elGamal, publicKey, subset);
        
        // 1.
        var r1 = group.getZModOrder().getRandomElement();
        Pair encOne = elGamal.encrypt(publicKey, encodedOne, r1);
        Triple proofOne = proofSystem.generate(proofSystem.createPrivateInput(r1, 1), encOne);

        var r2 = group.getZModOrder().getRandomElement();
        Pair encZero = elGamal.encrypt(publicKey, encodedZero, r2);
        Triple proofZero = proofSystem.generate(proofSystem.createPrivateInput(r2, 0), encZero);

        var r3 = group.getZModOrder().getRandomElement();
		Pair encZero2 = elGamal.encrypt(publicKey, encodedZero, r3);
        Triple proofZero2 = proofSystem.generate(proofSystem.createPrivateInput(r3, 0), encZero2);     

        // 2.
        Subset subsetSum = Subset.getInstance(group, encodedOne, impossibleElement);
        ElGamalEncryptionValidityProofSystem proofSystemSum = ElGamalEncryptionValidityProofSystem.getInstance(challengeGenerator, elGamal, publicKey, subsetSum);
        Tuple encSum = encOne.apply(encZero.apply(encZero2));
        var r = r1.add(r2.add(r3));
        Triple proofSum = proofSystemSum.generate(proofSystemSum.createPrivateInput(r, 0), encSum);
        
        Pair[] ciphertexts = new Pair[3];
        Triple[] proofs = new Triple[3];
        switch (vote){
            case "Yes":
                ciphertexts[0] = encOne;
                ciphertexts[1] = encZero;
                ciphertexts[2] = encZero2;
                proofs[0] = proofOne;
                proofs[1] = proofZero;
                proofs[2] = proofZero2;
                break;
            case "No":
                ciphertexts[0] = encZero;
                ciphertexts[1] = encOne;
                ciphertexts[2] = encZero2;
                proofs[0] = proofZero;
                proofs[1] = proofOne;
                proofs[2] = proofZero2;
                break;
            case "Abstain":
                ciphertexts[0] = encZero;
                ciphertexts[1] = encZero2;
                ciphertexts[2] = encOne;
                proofs[0] = proofZero;
                proofs[1] = proofZero2;
                proofs[2] = proofOne;
                break;
            default:
                break;
        }
        // Generation of the signature
        String fullCiphertext = "";
        for (Pair ciphertext: ciphertexts){
            fullCiphertext += ciphertext.getFirst().getValue().toString() + ciphertext.getSecond().getValue().toString();
        }
        Tuple signature = schnorr.sign(signPrivateKey, schnorr.getMessageSpace().getElement(fullCiphertext));
        // Creation of the object of class Vote
        Vote encVote = new Vote(ciphertexts, proofs, proofSum, signature);
        return encVote;
    }

    // ---------- Graphic methods definition ----------
    
    /**
     * Generate login panel
     */
    static public void generateLoginPanel(){
        // Set layout
        loginPanel.setLayout(null);

        // Set fonts
        loginLabel.setFont(new Font("DialogInput", Font.BOLD, 20));
        usernameLabel.setFont(new Font("DialogInput", Font.PLAIN, 14));
        usernameField.setFont(new Font("DialogInput", Font.PLAIN, 12));
        passwordLabel.setFont(new Font("DialogInput", Font.PLAIN, 14));
        loginButton.setFont(new Font("DialogInput", Font.BOLD, 14));
        signupButton.setFont(new Font("DialogInput", Font.BOLD, 12));

        // Set positions and dimensions
        loginLabel.setBounds(400,80,80,25);
        usernameLabel.setBounds(400,140,80,25);
        usernameField.setBounds(400,170,200,25);
        passwordLabel.setBounds(400,200,80,25);
        passwordField.setBounds(400,230,200,25);
        loginButton.setBounds(400,290,200,25);
        signupButton.setBounds(25,15,90,25);

        // Set colors
        loginButton.setBackground(buttonColor);
        signupButton.setBackground(buttonColor);

        // Set command to button
        loginButton.setActionCommand("Login");
        signupButton.setActionCommand("Sign up");

        // Add GUI objects to the panel
        loginPanel.add(loginLabel);
        loginPanel.add(usernameLabel);
		loginPanel.add(usernameField);
        loginPanel.add(passwordLabel);
        loginPanel.add(passwordField);
        loginPanel.add(loginButton);
        loginPanel.add(signupButton);

        // Add action listeners to the buttons to capture user response on buttons
        if(loginButton.getActionListeners().length == 0){
            loginButton.addActionListener(ct);
        }
        if(signupButton.getActionListeners().length == 0){
            signupButton.addActionListener(ct);
        }
    }

    /**
     * Generate sign up panel
     */
    static public void generateSignupPanel(){
        // Set layout
        signupPanel.setLayout(null);

        // Group radio buttons
        buttonGroup.add(voterRadioButton);
        buttonGroup.add(researcherRadioButton);

        // Set properties
        voterRadioButton.setSelected(true);

        // Set fonts
        signupLabel.setFont(new Font("DialogInput", Font.BOLD, 20));
        usernameLabel2.setFont(new Font("DialogInput", Font.PLAIN, 14));
        usernameField2.setFont(new Font("DialogInput", Font.PLAIN, 12));
        passwordLabel2.setFont(new Font("DialogInput", Font.PLAIN, 14));
        passwordLabel3.setFont(new Font("DialogInput", Font.PLAIN, 14));
        voterRadioButton.setFont(new Font("DialogInput", Font.PLAIN, 12));
        researcherRadioButton.setFont(new Font("DialogInput", Font.PLAIN, 12));
        signupButton2.setFont(new Font("DialogInput", Font.BOLD, 14));
        backtoLoginButton.setFont(new Font("DialogInput", Font.BOLD, 12));
        errorLabel2.setFont(new Font("DialogInput", Font.PLAIN, 9));
        errorLabel3.setFont(new Font("DialogInput", Font.PLAIN, 9));
        errorLabel4.setFont(new Font("DialogInput", Font.PLAIN, 9));
        errorLabel5.setFont(new Font("DialogInput", Font.PLAIN, 12));
        
        // Set positions and dimensions
        signupLabel.setBounds(400,80,100,25);
        usernameLabel2.setBounds(400,140,80,25);
        usernameField2.setBounds(400,170,200,25);
        passwordLabel2.setBounds(400,200,80,25);
        passwordField2.setBounds(400,230,200,25);
        passwordLabel3.setBounds(400,260,150,25);
        passwordField3.setBounds(400,290,200,25);
        voterRadioButton.setBounds(400,330,80,20);
        researcherRadioButton.setBounds(500,330,100,20);
        signupButton2.setBounds(400,370,200,25);
        backtoLoginButton.setBounds(25,15,80,25);
        errorLabel2.setBounds(610,156,370,50);
        errorLabel3.setBounds(610,215,370,50);
        errorLabel4.setBounds(610,276,370,50);
        errorLabel5.setBounds(393,400,260,50);

        // Set colors
        signupButton2.setBackground(buttonColor);
        backtoLoginButton.setBackground(buttonColor);
        errorLabel2.setForeground(errorColor);
        errorLabel3.setForeground(errorColor);
        errorLabel4.setForeground(errorColor);
        errorLabel5.setForeground(errorColor);

        // Set command to button
        voterRadioButton.setActionCommand("voter");
        researcherRadioButton.setActionCommand("researcher");
        signupButton2.setActionCommand("Register credentials");
        backtoLoginButton.setActionCommand("Back to login");

        // Add GUI objects to the panel
        signupPanel.add(signupLabel);
        signupPanel.add(usernameLabel2);
		signupPanel.add(usernameField2);
        signupPanel.add(passwordLabel2);
        signupPanel.add(passwordField2);
        signupPanel.add(passwordLabel3);
        signupPanel.add(passwordField3);
        signupPanel.add(voterRadioButton);
        signupPanel.add(researcherRadioButton);
        signupPanel.add(signupButton2);
        signupPanel.add(backtoLoginButton);

        // Add action listeners to the buttons to capture user response on buttons
        if(signupButton2.getActionListeners().length == 0){
            signupButton2.addActionListener(ct);
        }
        if(backtoLoginButton.getActionListeners().length == 0){
            backtoLoginButton.addActionListener(ct);
        }
    }

    /**
     * Generate researcher surveys panel (scrollable panel)
     */
    public void generateResearcherSurveysPanel(){
        boolean flag = true;

        // Remove previous objects
        researcherSurveysPanel.removeAll();

        // Set layout
        researcherSurveysPanel.setLayout(new BoxLayout(researcherSurveysPanel, BoxLayout.Y_AXIS));

        for (Survey survey: surveys){
            // Create single panel for the survey
            JPanel surveyPanel = new JPanel();

            // Set layout
            surveyPanel.setLayout(null);

            // Set positions and dimensions
            surveyPanel.setMaximumSize(new Dimension(1800, 50));
            surveyPanel.setMinimumSize(new Dimension(1800, 50));
            surveyPanel.setSize(900, 50);

            if (survey.getStatus()){
                // Create objects to add to the panel
                JPanel labelPanel = new JPanel();
                JLabel surveyLabel = new JLabel(survey.getTitle());
                JPanel labelPanel2 = new JPanel();
                JLabel statusLabel = new JLabel("open");
                JLabel statusLabel2 = new JLabel(survey.getNumvotes() + " votes");
                JPanel buttonPanel = new JPanel();
                JButton closesurveyButton = new JButton("CLOSE");

                // Set layouts
                labelPanel.setLayout(null);
                labelPanel2.setLayout(null);
                buttonPanel.setLayout(null);    

                // Set properties
                closesurveyButton.setName(Integer.toString(survey.getId()));

                // Set fonts
                surveyLabel.setFont(new Font("DialogInput", Font.PLAIN, 12));
                statusLabel.setFont(new Font("DialogInput", Font.BOLD, 14));
                statusLabel2.setFont(new Font("DialogInput", Font.PLAIN, 12));
                closesurveyButton.setFont(new Font("DialogInput", Font.BOLD, 12));

                // Set positions and dimensions
                labelPanel.setBounds(0,0,680,50);
                labelPanel2.setBounds(680,0,110,50);
                buttonPanel.setBounds(790,0,110, 50);
                surveyLabel.setBounds(5,5,670,40);
                statusLabel.setBounds(0,5,110,20);
                statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
                statusLabel2.setBounds(0,25,110,20);
                statusLabel2.setHorizontalAlignment(SwingConstants.CENTER);
                closesurveyButton.setBounds(15,15,80,20);

                // Set colors
                if (flag) {
                    labelPanel.setBackground(firstAlternatingColor);
                    labelPanel2.setBackground(firstAlternatingColor2);
                    buttonPanel.setBackground(firstAlternatingColor);
                } else {
                    labelPanel.setBackground(secondAlternatingColor);
                    labelPanel2.setBackground(secondAlternatingColor2);
                    buttonPanel.setBackground(secondAlternatingColor);
                }
                flag = !flag;
                closesurveyButton.setBackground(buttonColor);

                // Set command to button
                closesurveyButton.setActionCommand("Close");

                // Add GUI objects to the panels
                labelPanel.add(surveyLabel);
                surveyPanel.add(labelPanel);
                labelPanel2.add(statusLabel);
                labelPanel2.add(statusLabel2);
                surveyPanel.add(labelPanel2);
                buttonPanel.add(closesurveyButton);
                surveyPanel.add(buttonPanel);

                // Add action listeners to the buttons to capture user response on buttons
                closesurveyButton.addActionListener(ct);
            }else{
                // Create objects to add to the panel
                JPanel labelPanel = new JPanel();
                JLabel surveyLabel = new JLabel(survey.getTitle());
                JPanel labelPanel2 = new JPanel();
                JLabel statusLabel = new JLabel("closed");
                JPanel labelPanel3 = new JPanel();
                int[] result = survey.getResult();
                JLabel resultsLabel = new JLabel(result[0] + " " + result[1] + " " + result[2]);

                // Set layouts
                labelPanel.setLayout(null);
                labelPanel2.setLayout(null);
                labelPanel3.setLayout(null);    

                // Set fonts
                surveyLabel.setFont(new Font("DialogInput", Font.PLAIN, 12));
                statusLabel.setFont(new Font("DialogInput", Font.BOLD, 14));
                resultsLabel.setFont(new Font("DialogInput", Font.PLAIN, 12));

                // Set positions and dimensions
                labelPanel.setBounds(0,0,680,50);
                labelPanel2.setBounds(680,0,110,50);
                labelPanel3.setBounds(790,0,110, 50);
                surveyLabel.setBounds(5,5,670,40);
                statusLabel.setBounds(0,0,110,50);
                statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
                resultsLabel.setBounds(0,0,110,50);
                resultsLabel.setHorizontalAlignment(SwingConstants.CENTER);
                resultsLabel.setVerticalAlignment(SwingConstants.CENTER);

                // Set colors
                if (flag) {
                    labelPanel.setBackground(firstAlternatingColor);
                    labelPanel2.setBackground(firstAlternatingColor2);
                    labelPanel3.setBackground(firstAlternatingColor);
                } else {
                    labelPanel.setBackground(secondAlternatingColor);
                    labelPanel2.setBackground(secondAlternatingColor2);
                    labelPanel3.setBackground(secondAlternatingColor);
                }
                flag = !flag;

                // Add GUI objects to the panels
                labelPanel.add(surveyLabel);
                surveyPanel.add(labelPanel);
                labelPanel2.add(statusLabel);
                surveyPanel.add(labelPanel2);
                labelPanel3.add(resultsLabel);
                surveyPanel.add(labelPanel3);
            }
            // Add panel to external panel
            researcherSurveysPanel.add(surveyPanel);
        }
        // Set dimensions
        researcherSurveysPanel.setPreferredSize(new Dimension(900, ((int)researcherSurveysPanel.getMinimumSize().getHeight())));
    }

    /**
     * Generate the researcher panel
     */
    public void generateResearcherPanel(){
        // Set layout
        researcherMainPanel.setLayout(null);

        // Generate surveys panel
        generateResearcherSurveysPanel();
        researcherScrollPane = new JScrollPane(researcherSurveysPanel, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        // Set properties
        loggedInLabel.setText("<html>Logged in as: <b>" + username + "</b></html>");

        // Set fonts
        loggedInLabel.setFont(new Font("DialogInput", Font.PLAIN, 12));
        logoutButton.setFont(new Font("DialogInput", Font.BOLD, 12));
        researcherLabel.setFont(new Font("DialogInput", Font.BOLD, 20));
        newsurveyButton.setFont(new Font("DialogInput", Font.BOLD, 14));
        researcherColumnLabel1.setFont(new Font("DialogInput", Font.BOLD, 14));
        researcherColumnLabel2.setFont(new Font("DialogInput", Font.BOLD, 14));
        researcherColumnLabel3.setFont(new Font("DialogInput", Font.BOLD, 14));

        // Set positions and dimensions
        loggedInLabel.setBounds(25, 10, 800, 15);
        logoutButton.setBounds(25,28,80,20);
        researcherLabel.setBounds(350,40,300,25);
        researcherLabel.setHorizontalAlignment(SwingConstants.CENTER);
        newsurveyButton.setBounds(350,80,300,25);
        int shift = 0;
        if (researcherSurveysPanel.getPreferredSize().height >= 250){
            shift = (int)(researcherScrollPane.getVerticalScrollBar().getPreferredSize().getWidth()/2);
        }
        researcherColumnLabel1.setBounds(50 - shift,130,680,25);
        researcherColumnLabel2.setBounds(725 - shift,130,110,25);
        researcherColumnLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        researcherColumnLabel3.setBounds(835 - shift,105,110,50);
        researcherColumnLabel3.setHorizontalAlignment(SwingConstants.CENTER);
        researcherScrollPane.setBounds(45 - shift,155,900 + 2 * shift,250);

        // Set colors
        logoutButton.setBackground(buttonColor);
        newsurveyButton.setBackground(buttonColor);
        researcherScrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {@Override protected void configureScrollBarColors(){this.thumbColor = buttonColor;}});
        researcherScrollPane.getVerticalScrollBar().getComponent(0).setBackground(buttonColor);
        researcherScrollPane.getVerticalScrollBar().getComponent(1).setBackground(buttonColor);
        researcherScrollPane.setBorder(BorderFactory.createEmptyBorder());

        // Set command to button
        logoutButton.setActionCommand("Logout");
        newsurveyButton.setActionCommand("Create");

        // Add GUI objects to the frame
        researcherMainPanel.add(loggedInLabel);
        researcherMainPanel.add(logoutButton);
        researcherMainPanel.add(researcherLabel);
        researcherMainPanel.add(newsurveyButton);
        researcherMainPanel.add(researcherColumnLabel1);
        researcherMainPanel.add(researcherColumnLabel2);
        researcherMainPanel.add(researcherColumnLabel3);
        researcherMainPanel.add(researcherScrollPane);

        // Add action listeners to the buttons to capture user response on buttons
        if(logoutButton.getActionListeners().length == 0){
            logoutButton.addActionListener(ct);
        }
        if(newsurveyButton.getActionListeners().length == 0){
            newsurveyButton.addActionListener(ct);
        }
    }

    /**
     * Refresh researcher panel
     */
    public void refreshResearcherPanel(){
        // Remove previous objects
        researcherMainPanel.remove(researcherScrollPane);

        // Generate surveys panel
        generateResearcherSurveysPanel();
        researcherScrollPane = new JScrollPane(researcherSurveysPanel, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        // Set positions and dimensions
        int shift = 0;
        if (researcherSurveysPanel.getPreferredSize().height >= 250){
            shift = (int)(researcherScrollPane.getVerticalScrollBar().getPreferredSize().getWidth()/2);
        }
        researcherColumnLabel1.setBounds(50 - shift,130,680,25);
        researcherColumnLabel2.setBounds(725 - shift,130,110,25);
        researcherColumnLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        researcherColumnLabel3.setBounds(835 - shift,105,110,50);
        researcherColumnLabel3.setHorizontalAlignment(SwingConstants.CENTER);
        researcherScrollPane.setBounds(45 - shift,155,900 + 2 * shift,250);

        // Set colors
        researcherScrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {@Override protected void configureScrollBarColors(){this.thumbColor = buttonColor;}});
        researcherScrollPane.getVerticalScrollBar().getComponent(0).setBackground(buttonColor);
        researcherScrollPane.getVerticalScrollBar().getComponent(1).setBackground(buttonColor);
        researcherScrollPane.setBorder(BorderFactory.createEmptyBorder());

        // Add GUI objects to the frame
        researcherMainPanel.add(researcherColumnLabel1);
        researcherMainPanel.add(researcherColumnLabel2);
        researcherMainPanel.add(researcherColumnLabel3);
        researcherMainPanel.add(researcherScrollPane);
    }

    /**
     * Generate voter surveys panel (scrollable panel)
     */
    public void generateVoterSurveysPanel(){
        boolean flag = true;

        // Remove previous objects
        voterSurveysPanel.removeAll();

        // Set layout
        voterSurveysPanel.setLayout(new BoxLayout(voterSurveysPanel, BoxLayout.Y_AXIS));

        // Add GUI objects to the frame
        for (Survey survey: surveys){
            // Create single panel for the survey
            JPanel surveyPanel = new JPanel();

            // Set layout
            surveyPanel.setLayout(null);

            // Set positions and dimensions
            surveyPanel.setMaximumSize(new Dimension(1800, 50));
            surveyPanel.setMinimumSize(new Dimension(1800, 50));
            surveyPanel.setSize(900, 50);

            // Create objects to add to the panel
            JPanel labelPanel = new JPanel();
            JLabel surveyLabel = new JLabel(survey.getTitle());
            JPanel buttonPanel = new JPanel();
            JButton votesurveyButton = new JButton("VOTE");

            // Set layouts
            labelPanel.setLayout(null);
            buttonPanel.setLayout(null);  

            // Set properties
            votesurveyButton.setName(Integer.toString(survey.getId()));

            // Set fonts
            surveyLabel.setFont(new Font("DialogInput", Font.PLAIN, 12));
            votesurveyButton.setFont(new Font("DialogInput", Font.BOLD, 12));

            // Set positions and dimensions
            labelPanel.setBounds(0,0,790,50);
            buttonPanel.setBounds(790,0,110, 50);
            surveyLabel.setBounds(5,5,780,40);
            votesurveyButton.setBounds(15,15,80,20);

            // Set colors
            if (flag) {
                labelPanel.setBackground(firstAlternatingColor2);
                buttonPanel.setBackground(firstAlternatingColor);
            } else {
                labelPanel.setBackground(secondAlternatingColor2);
                buttonPanel.setBackground(secondAlternatingColor);
            }
            flag = !flag;
            votesurveyButton.setBackground(buttonColor);

            // Set command to button
            votesurveyButton.setActionCommand("Vote");

            // Add GUI objects to the panels
            labelPanel.add(surveyLabel);
            surveyPanel.add(labelPanel);
            buttonPanel.add(votesurveyButton);
            surveyPanel.add(buttonPanel);

            // Add action listeners to the buttons to capture user response on buttons
            votesurveyButton.addActionListener(ct);

            // Add panel to external panel
            voterSurveysPanel.add(surveyPanel);
        }
        // Set dimensions
        voterSurveysPanel.setPreferredSize(new Dimension(900, ((int)voterSurveysPanel.getMinimumSize().getHeight())));
    }

    /**
     * Generate the voter panel
     */
    public void generateVoterPanel(){
        // Set layout
        voterMainPanel.setLayout(null);

        // Generate surveys panel
        generateVoterSurveysPanel();
        voterScrollPane = new JScrollPane(voterSurveysPanel, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        // Set properties
        loggedInLabel.setText("<html>Logged in as: <b>" + username + "</b></html>");

        // Set fonts
        loggedInLabel.setFont(new Font("DialogInput", Font.PLAIN, 12));
        logoutButton.setFont(new Font("DialogInput", Font.BOLD, 12));
        voterLabel.setFont(new Font("DialogInput", Font.BOLD, 20));
        voterColumnLabel.setFont(new Font("DialogInput", Font.BOLD, 14));

        // Set positions and dimensions
        loggedInLabel.setBounds(25, 10, 800, 15);
        logoutButton.setBounds(25,28,80,20);
        voterLabel.setBounds(342,40,300,25);
        voterLabel.setHorizontalAlignment(SwingConstants.CENTER);
        int shift = 0;
        if (voterSurveysPanel.getPreferredSize().height >= 300){
            shift = (int)(voterScrollPane.getVerticalScrollBar().getPreferredSize().getWidth()/2);
        }
        voterColumnLabel.setBounds(50 - shift,90,900 + 2 * shift,25);
        voterScrollPane.setBounds(45 - shift,115,900 + 2 * shift,300);

        // Set colors
        logoutButton.setBackground(buttonColor);
        voterScrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {@Override protected void configureScrollBarColors(){this.thumbColor = buttonColor;}});
        voterScrollPane.getVerticalScrollBar().getComponent(0).setBackground(buttonColor);
        voterScrollPane.getVerticalScrollBar().getComponent(1).setBackground(buttonColor);
        voterScrollPane.setBorder(BorderFactory.createEmptyBorder());

        // Set command to button
        logoutButton.setActionCommand("Logout");

        // Add GUI objects to the frame
        voterMainPanel.add(loggedInLabel);
        voterMainPanel.add(logoutButton);
        voterMainPanel.add(voterLabel);
        voterMainPanel.add(voterColumnLabel);
        voterMainPanel.add(voterScrollPane);

        // Add action listeners to the buttons to capture user response on buttons
        if(logoutButton.getActionListeners().length == 0){
            logoutButton.addActionListener(ct);
        }
    }

    /**
     * Refresh the voter panel
     */
    public void refreshVoterPanel(){
        // Remove previous objects
        voterMainPanel.remove(voterScrollPane);

        // Generate surveys panel
        generateVoterSurveysPanel();
        voterScrollPane = new JScrollPane(voterSurveysPanel, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        // Set positions and dimensions
        int shift = 0;
        if (voterSurveysPanel.getPreferredSize().height >= 300){
            shift = (int)(voterScrollPane.getVerticalScrollBar().getPreferredSize().getWidth()/2);
        }
        voterColumnLabel.setBounds(50 - shift,90,900 + 2 * shift,25);
        voterScrollPane.setBounds(45 - shift,115,900 + 2 * shift,300);

        // Set colors
        voterScrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {@Override protected void configureScrollBarColors(){this.thumbColor = buttonColor;}});
        voterScrollPane.getVerticalScrollBar().getComponent(0).setBackground(buttonColor);
        voterScrollPane.getVerticalScrollBar().getComponent(1).setBackground(buttonColor);
        voterScrollPane.setBorder(BorderFactory.createEmptyBorder());

        // Add GUI objects to the frame
        voterMainPanel.add(voterColumnLabel);
        voterMainPanel.add(voterScrollPane);
    }

    /**
     * Generate the survey panel
     */
    public void generateSurveyPanel(){
        // Set layout
        newsurveyPanel.setLayout(null);

        // Set properties
        loggedInLabel2.setText("<html>Logged in as: <b>" + username + "</b></html>");
        surveyArea.setLineWrap(true);
        surveyArea.setWrapStyleWord(true);

        // Set fonts
        loggedInLabel2.setFont(new Font("DialogInput", Font.PLAIN, 12));
        gobackButton.setFont(new Font("DialogInput", Font.BOLD, 12));
        researcherLabel2.setFont(new Font("DialogInput", Font.BOLD, 20));
        newsurveyLabel.setFont(new Font("DialogInput", Font.BOLD, 14));
        surveyArea.setFont(new Font("DialogInput", Font.PLAIN, 12));
        opensurveyButton.setFont(new Font("DialogInput", Font.BOLD, 14));

        // Set positions and dimensions
        loggedInLabel2.setBounds(25, 10, 800, 15);
        gobackButton.setBounds(25,28,80,20);
        researcherLabel2.setBounds(350,40,300,25);
        researcherLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        newsurveyLabel.setBounds(255,105,500,25);
        surveyArea.setBounds(250,130,500,87);
        opensurveyButton.setBounds(460,250,80,25);

        // Set colors
        gobackButton.setBackground(buttonColor);
        surveyArea.setBorder(BorderFactory.createLineBorder(buttonColor));
        opensurveyButton.setBackground(buttonColor);

        // Set command to button
        gobackButton.setActionCommand("Back");
        opensurveyButton.setActionCommand("Open");

        // Add GUI objects to the frame
        newsurveyPanel.add(loggedInLabel2);
        newsurveyPanel.add(gobackButton);
        newsurveyPanel.add(researcherLabel2);
        newsurveyPanel.add(newsurveyLabel);
        newsurveyPanel.add(surveyArea);
        newsurveyPanel.add(opensurveyButton);

        // Add action listeners to the buttons to capture user response on buttons
        if(gobackButton.getActionListeners().length == 0){
            gobackButton.addActionListener(ct);
        }
        if(opensurveyButton.getActionListeners().length == 0){
            opensurveyButton.addActionListener(ct);
        }
    }

    /**
     * Generate the vote panel
     */
    public void generateVotePanel(){
        // Set layout
        votePanel.setLayout(null);

        // Set properties
        loggedInLabel2.setText("<html>Logged in as: <b>" + username + "</b></html>");

        // Set fonts
        loggedInLabel2.setFont(new Font("DialogInput", Font.PLAIN, 12));
        gobackButton.setFont(new Font("DialogInput", Font.BOLD, 12));
        voterLabel2.setFont(new Font("DialogInput", Font.BOLD, 20));
        surveyLabel.setFont(new Font("DialogInput", Font.PLAIN, 12));
        yesButton.setFont(new Font("DialogInput", Font.BOLD, 14));
        noButton.setFont(new Font("DialogInput", Font.BOLD, 14));
        abstainButton.setFont(new Font("DialogInput", Font.BOLD, 14));

        // Set positions and dimensions
        loggedInLabel2.setBounds(25, 10, 800, 15);
        gobackButton.setBounds(25,28,80,20);
        voterLabel2.setBounds(342,40,300,25);
        voterLabel2.setHorizontalAlignment(SwingConstants.CENTER);
        surveyLabel.setBounds(250,130,500,100);
        surveyLabel.setHorizontalAlignment(SwingConstants.CENTER);
        yesButton.setBounds(250,300,100,25);
        noButton.setBounds(450,300,100,25);
        abstainButton.setBounds(650,300,100,25);

        // Set colors
        gobackButton.setBackground(buttonColor);
        yesButton.setBackground(buttonColor);
        noButton.setBackground(buttonColor);
        abstainButton.setBackground(buttonColor);

        // Set commands to buttons
        gobackButton.setActionCommand("Back");
        yesButton.setActionCommand("Yes");
        noButton.setActionCommand("No");
        abstainButton.setActionCommand("Abstain");

        // Add GUI objects to the frame
        votePanel.add(loggedInLabel2);
        votePanel.add(gobackButton);
        votePanel.add(voterLabel2);

        // Add action listeners to the buttons to capture user response on buttons
        if(gobackButton.getActionListeners().length == 0){
            gobackButton.addActionListener(ct);
        }
        if(yesButton.getActionListeners().length == 0){
            yesButton.addActionListener(ct);
        }
        if(noButton.getActionListeners().length == 0){
            noButton.addActionListener(ct);
        }
        if(abstainButton.getActionListeners().length == 0){
            abstainButton.addActionListener(ct);
        }
    }

    /**
     * Refresh the vote panel
     * @param title the title of the survey
     * @param id the id associated to the survey
     */
    public void refreshVotePanel(String title, int id){
        // Set properties
        surveyLabel.setText("<html>" + title + "</html>");
        yesButton.setName(Integer.toString(id));
        noButton.setName(Integer.toString(id));
        abstainButton.setName(Integer.toString(id));

        // Add GUI objects to the frame
        votePanel.add(surveyLabel);
        votePanel.add(yesButton);
        votePanel.add(noButton);
        votePanel.add(abstainButton);
    }


    // ---------- Main ----------

	public static void main(String args[]) {
		// Set the size and the location of the frame
		frame.setSize(1000, 500);
        frame.setLocationRelativeTo(null);
		// Set the frame's visibility
		frame.setVisible(true);
        // Exit when window is closed
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Generate initial panels
        generateLoginPanel();
        generateSignupPanel();
        // Add login panel to the frame
		frame.add(loginPanel);
        frame.revalidate();
        frame.repaint();
	}

    // ---------- Actions management ----------

	public void actionPerformed(ActionEvent evt) {
        // Button-dependent variables
		String com = evt.getActionCommand();
        JButton button = (JButton)evt.getSource();
        String buttonname = button.getName();
        String title = "";
        int id = 0;
        switch (com) {
            // Login button
            case "Login":
                // Get inserted credentials
                username = usernameField.getText();
                char[] password = passwordField.getPassword();
                // Reset text field
                passwordField.setText(null);
                // Ask the server to check credentials and return the role
                role = server.readCredentials(username, password);
                // Clear password variable
                for (int i = 0; i < password.length; i++){
                    password[i] = ' ';
                }
                password = null;
                // If an error has been raised
                if (role.equals("error")){
                    // Reset values
                    username = null;
                    // Add error labels to the panel
                    errorLabel.setFont(new Font("DialogInput", Font.PLAIN, 12));
                    errorLabel.setForeground(errorColor);
                    errorLabel.setBounds(375,320,260,50);
                    loginPanel.add(errorLabel); 
                }else{
                    //Read surveys related to this user
                    surveys = server.serverReadSurveys();
                    // Reset text field
                    usernameField.setText(null);
                    // Refresh frame
                    frame.remove(loginPanel);
                    loginPanel.remove(errorLabel);
                    if(role.equals("researcher")){
                        // Generate researcher panels
                        generateResearcherPanel();
                        generateSurveyPanel();
                        // Add researcher panel to the frame
                        frame.add(researcherMainPanel);
                    }else{
                        // Generate voter panels
                        generateVoterPanel();
                        generateVotePanel();
                        // Add voter panel to the frame
                        frame.add(voterMainPanel); 
                    }
                }
                frame.revalidate();
                frame.repaint();  
                break;
            // Sign up button
            case "Sign up":
                // Reset text fields
                usernameField.setText(null);
                passwordField.setText(null);
                // Refresh frame
                loginPanel.remove(errorLabel);
                frame.remove(loginPanel);
                frame.add(signupPanel);
                frame.revalidate();
                frame.repaint();
                break;
            // Register credentials button
            case "Register credentials":
                // Get inserted credentials
                String tempusername = usernameField2.getText();
                char[] temppassword = passwordField2.getPassword();
                char[] checkpassword = passwordField3.getPassword();
                // Reset text field
                passwordField2.setText(null);
                passwordField3.setText(null);
                // Check the validity of the username and the password
                boolean[] validity = checkCredentials(tempusername, temppassword, checkpassword);
                // Clear password variable
                for (int i = 0; i < checkpassword.length; i++){
                    checkpassword[i] = ' ';
                }
                checkpassword = null;
                // If the inserted credentials are valid
                if (validity[0] && validity[1] && validity[2]){
                    // Refresh frame
                    signupPanel.remove(errorLabel2);
                    signupPanel.remove(errorLabel3);
                    // Get selected role
                    String temprole;
                    if (voterRadioButton.isSelected()){
                        temprole = voterRadioButton.getActionCommand();
                    } else {
                        temprole = researcherRadioButton.getActionCommand();
                    }
                    // Ask the server to register credentials (the server checks if they are already present in the credentials file)
                    // and return a boolean corresponding to the success of the operation
                    boolean result = server.registerCredentials(tempusername, temppassword, temprole);
                    // Clear password variable
                    for (int i = 0; i < temppassword.length; i++){
                        temppassword[i] = ' ';
                    }
                    temppassword = null;
                    // If the credential are already present in the system
                    if (!result){
                        // Add error label to the panel
                        signupPanel.add(errorLabel5); 
                    } else {
                        // Create client files
                        String tempSignPublicKey = createNewUser(tempusername, temprole);
                        // Update credentials file for the voter
                        if(temprole.equals("voter")){
                            server.registerPublicKey(tempSignPublicKey);
                        }
                        // Reset text field
                        usernameField2.setText(null);
                        // Reset radio buttons
                        voterRadioButton.setSelected(true);
                        // Refresh frame
                        signupPanel.remove(errorLabel5);
                        frame.remove(signupPanel);
                        frame.add(loginPanel);
                    }
                } else {
                    // Clear password variables
                    for (int i = 0; i < temppassword.length; i++){
                        temppassword[i] = ' ';
                    }
                    temppassword = null;
                    // Manage the error labels
                    signupPanel.remove(errorLabel5);
                    if (!validity[0]){
                        signupPanel.add(errorLabel2); 
                    } else {
                        signupPanel.remove(errorLabel2);
                    }
                    if (!validity[1]){
                        signupPanel.add(errorLabel3); 
                    } else {
                        signupPanel.remove(errorLabel3);
                    }
                    if (!validity[2]){
                        signupPanel.add(errorLabel4); 
                    } else {
                        signupPanel.remove(errorLabel4);
                    }
                }
                frame.revalidate();
                frame.repaint();
                break;
            // Back to login button
            case "Back to login":
                // Reset text fields
                usernameField2.setText(null);
                passwordField2.setText(null);
                // Reset radio buttons
                voterRadioButton.setSelected(true);
                // Refresh frame
                signupPanel.remove(errorLabel2);
                signupPanel.remove(errorLabel3);
                signupPanel.remove(errorLabel4);
                signupPanel.remove(errorLabel5);
                frame.remove(signupPanel);
                frame.add(loginPanel);
                frame.revalidate();
                frame.repaint();
                break;
            // Logout button
            case "Logout":
                // Reset panels and frame
                if (role.equals("researcher")){
                    frame.remove(researcherMainPanel);
                    researcherMainPanel.removeAll();
                    researcherSurveysPanel.removeAll();
                    newsurveyPanel.removeAll();
                } else {
                    frame.remove(voterMainPanel);
                    voterMainPanel.removeAll();
                    voterSurveysPanel.removeAll();
                    votePanel.removeAll();
                }
                // Reset variables
                username = null;
                surveys = null;
                role = null;
                server.setUsername(null);
                server.setNumsurveys(0);
                server.setSurveys(null);
                server.setRole(null);
                // Refresh frame
                frame.add(loginPanel);
                frame.revalidate();
                frame.repaint();
                break;
            // Create new survey button
            case "Create":
                // Refresh frame
                frame.remove(researcherMainPanel);
                frame.add(newsurveyPanel);
                frame.revalidate();
                frame.repaint();
                break;
            // Open new survey button
            case "Open":
                title = surveyArea.getText();

                // Create pair of keys associated to the survey
                var keyPair = elGamal.getKeyPairGenerator().generateKeyPair();
                var privateKey = keyPair.getFirst();
                var publicKey = keyPair.getSecond();

                // The server adds the new survey
                surveys = server.writeSurvey(title, publicKey.getValue().toString());
                surveys.get(surveys.size() - 1).writeSurvey("./researchers/" + username + ".txt", privateKey.getValue().toString());

                // Free variable containing private key and send object to garbage collector
                privateKey = null;
                System.gc();

                // Refresh frame
                frame.remove(newsurveyPanel);
                surveyArea.setText(null);
                refreshResearcherPanel();
                frame.add(researcherMainPanel);
                frame.revalidate();
                frame.repaint();
                break;
            // Close survey button
            case "Close":
                // The server closes the survey
                surveys = server.serverCloseSurvey(Integer.parseInt(buttonname));

                // Refresh frame
                frame.remove(researcherMainPanel);
                refreshResearcherPanel();
                frame.add(researcherMainPanel);
                frame.revalidate();
                frame.repaint();
                break;
            // Vote survey button
            case "Vote":
                for (Survey s: surveys){
                    // Search the survey 
                    if (s.getId() == Integer.parseInt(buttonname)){
                        title = s.getTitle();
                        id = s.getId();
                    }
                }

                // Refresh frame
                frame.remove(voterMainPanel);  
                refreshVotePanel(title, id);
                frame.add(votePanel);
                frame.revalidate();
                frame.repaint();
                break;
            // Yes/No/Abstain vote button
            case "Yes", "No", "Abstain":
                for (Survey s: surveys){
                    // Search the survey
                    if (s.getId() == Integer.parseInt(buttonname)){
                        var surveyPublicKey = s.getPublicKey();
                        // Application side: retrieve the private key
                        ZModElement signPrivateKey = s.voteSurvey("./voters/" + username + ".txt");
                        // Application side: encrypt the vote
                        Vote encVote = encryptVote(com, surveyPublicKey, signPrivateKey);
                        // Free variable containing private key and send object to garbage collector
                        signPrivateKey = null;
                        System.gc();
                        // Server side: send vote to the server that will memorize it in the 
                        // survey's file, add this survey in the user file
                        surveys = server.serverVoteSurvey(s.getId(), encVote);
                        break;
                    }
                }
                // Refresh frame
                frame.remove(votePanel);
                refreshVoterPanel();
                frame.add(voterMainPanel);
                frame.revalidate();
                frame.repaint();
                break;
            // Go back button
            case "Back":
                // Refresh frame
                if (role.equals("researcher")){
                    frame.remove(newsurveyPanel);
                    surveyArea.setText(null);
                    frame.add(researcherMainPanel);
                } else {
                    frame.remove(votePanel);
                    frame.add(voterMainPanel);
                }
                frame.revalidate();
                frame.repaint();
                break;
            default:
                break;
        }
	}
}
