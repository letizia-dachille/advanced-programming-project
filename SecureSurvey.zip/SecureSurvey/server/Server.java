// Java utilities packages
import java.io.*;
import java.math.BigInteger;
import java.util.*;
// Unicrypt library imports
import ch.bfh.unicrypt.crypto.schemes.hashing.PasswordHashingScheme;
import ch.bfh.unicrypt.helper.array.classes.ByteArray;
import ch.bfh.unicrypt.helper.hash.*;
import ch.bfh.unicrypt.helper.math.Alphabet;
import ch.bfh.unicrypt.helper.prime.SafePrime;
import ch.bfh.unicrypt.math.algebra.concatenative.classes.*;
import ch.bfh.unicrypt.math.algebra.general.classes.*;
import ch.bfh.unicrypt.math.algebra.multiplicative.classes.*;

/** Class used to simulate the server. Here we add methods that are properly done by the server */
public class Server {

	 // Session parameters
	private int numsurveys;
    private String username;
	private ArrayList<ServerSurvey> serverSurveys; 
	private String role;
	private GStarModElement signPublicKey;
    // Public parameters of schnorr signature scheme
    static SafePrime signSafePrime = SafePrime.getInstance(new BigInteger("5160289179960913922009630589553873386446241019346066584464789733730529820775975471558805071001746248628965281196631715655109211787623320097221593154021723397413011719734825864232550218292057819849916908621353330525916072743165961080647184413487006364873221639845813146666157485755176658930371463993970056677757245432617427952951731498672609884810444913435773165937698003676572685047604068221509587202023297212873219531499035553703317613901825962011464061665423331698093440057864951952119673263059442933268245837277755763504933073113278902151604780014211261994612488374092317481901995549233927884671313557525416210871791422878409622395862982552410160289950588703962692996276939322845431023867250713848696061595832893135813695573480799636518983135136110599909525694861264909900250864213944676652049701033110767457812408129043294318490225853306447730455615051514435305370888890407096401247663787658762826982331485609360468173807"));
    static GStarModSafePrime signGroup = GStarModSafePrime.getInstance(signSafePrime);
	// Parameters of password hashing
	static StringMonoid passwordSpace = StringMonoid.getInstance(Alphabet.PRINTABLE_ASCII);
	static HashAlgorithm hashAlgorithm = HashAlgorithm.getInstance("SHA-384");
	static HashMethod<ByteArray> hashMethod = HashMethod.getInstance(hashAlgorithm);
	static PasswordHashingScheme scheme = PasswordHashingScheme.getInstance(passwordSpace, hashMethod);

	/**
     * Number of surveys setter
     * @param numsurveys total number of existing surveys
     */
	public void setNumsurveys(int numsurveys){
		this.numsurveys = numsurveys;
	}

	/**
	 * Username setter
	 * @param username username of the user currently logged in
	 */
    public void setUsername(String username){
        this.username = username;
    }
	
	/**
	 * Surveys setter
	 * @param serverSurveys arraylist of objects of the class ServerSurvey representing 
	 * 		  the surveys related to the user currently logged in
	 */
    public void setSurveys(ArrayList<ServerSurvey> serverSurveys){
        this.serverSurveys = serverSurveys;
    }

	/**
	 * Role setter
	 * @param role role of the user currently logged in
	 */
    public void setRole(String role){
        this.role = role;
    }

	/**
     * Number of surveys getter
     * @return the total number of existing surveys
     */
    public int getNumsurveys(){
        return numsurveys;
    }

	/**
	 * Username getter
	 * @return the username of the user currently logged in
	 */
    public String getUsername(){
        return username;
    }

	
	/**
	 * Role getter
	 * @return the role of the user currently logged in
	 */
    public String getRole(){
        return role;
    }

	/**
	 * Called when a user is trying to sign up.
	 * Checks if credentials are already present in the system, otherwise registers them.
	 * @param tempusername inserted username
	 * @param temppassword inserted password
	 * @param temprole inserted role
	 * @return true if the credentials are registered, false otherwise
	 */
    public boolean registerCredentials(String tempusername, char[] temppassword, String temprole) {
		boolean result = true;
        InputStreamReader isr = null;
        Scanner s = null;
		OutputStreamWriter osw = null;
		// Read the file of credentials to search for the inserted username
        try{
            try{
                isr = new InputStreamReader(new FileInputStream("./server/credentials.txt"), "UTF-8");
                s = new Scanner(isr);
                while(s.hasNextLine()){
                    String str = s.nextLine();
                    String[] info = str.split(" ");
					// If the username is found in the credentials
                    if (tempusername.equals(info[0])){
						result = false;
                    }
                }
            }finally{
                if (isr != null) isr.close();
                if (s != null) s.close();
            }
			// In case the username was not present
			if (result){
				// Generate salt and hash of password
				StringElement passwordString = passwordSpace.getElement(new String(temppassword));
				ByteArrayElement salt = ByteArrayElement.getInstance(ByteArray.getRandomInstance(8));
				String saltString = Base64.getEncoder().encodeToString(salt.convertToByteArray().getBytes());						
				FiniteByteArrayElement hash = scheme.hash(passwordString, salt);
				String hashString = Base64.getEncoder().encodeToString(hash.convertToByteArray().getBytes());
				// Register the user on the server files
				try{
					osw = new OutputStreamWriter(new FileOutputStream("./server/credentials.txt", true), "UTF-8");
					osw.append("\n" + tempusername + " " + hashString + " " + saltString + " " + temprole);
				}finally{
					if (osw != null) osw.close();
				}
				if (temprole.equals("voter")){
					try{
						osw = new OutputStreamWriter(new FileOutputStream("./server/voters/" + tempusername + ".txt"), "UTF-8");
						osw.write("");
					}finally{
						if (osw != null) osw.close();
					}
				}
			}
        }catch (IOException ex) {
            // In case of reading/writing error print error on console and return false
            System.out.println(ex);
			result = false;
        }
		return result;
    }
	
	/**
	 * Called when a voter has signed up
	 * Registers the public key of the voter on the credentials file
	 * @param tempSignPublicKey public key of the voter that has signed up
	 */
    public void registerPublicKey(String tempSignPublicKey) {
		OutputStreamWriter osw = null;
		try{
			try{
				osw = new OutputStreamWriter(new FileOutputStream("./server/credentials.txt", true), "UTF-8");
				osw.append(" " + tempSignPublicKey);
			}finally{
				if (osw != null) osw.close();
			}
		}catch (IOException ex) {
			// In case of reading/writing error print error on console
			System.out.println(ex);
		}
	}

	/**
	 * Called when a user is trying to log in
	 * Checks their credentials comparing the hash with the related stored value
	 * @param username inserted username
	 * @param password inserted password
	 * @return the role of the user if the check succeeds, "error" otherwise
	 */
    public String readCredentials(String username, char[] password) {
        InputStreamReader isr = null;
        Scanner s = null;
		// Read the file of credentials to search for the username
        try{
            try{
                isr = new InputStreamReader(new FileInputStream("./server/credentials.txt"), "UTF-8");
                s = new Scanner(isr);
                while(s.hasNextLine()){
                    String str = s.nextLine();
                    String[] info = str.split(" ");
					// If the username is found
                    if (username.equals(info[0])){
						// Compute hash and compare with the stored value
						StringElement passwordString = passwordSpace.getElement(new String(password));
						ByteArrayElement salt = ByteArrayElement.getInstance(ByteArray.getInstance(Base64.getDecoder().decode(info[2])));
						FiniteByteArrayElement hash = FiniteByteArrayElement.getInstance(ByteArray.getInstance(Base64.getDecoder().decode(info[1])));
						BooleanElement result = scheme.check(passwordString, salt, hash);
						// If the check succeeds
                        if (result.isTrue()){
							this.username = username;
							this.role = info[3];
							if (role.equals("voter")){
								signPublicKey = signGroup.getElement(new BigInteger(info[4]));
							}
                            return role;
                        }
                        return "error";
                    }
                }
                return "error";
            }finally{
                if (isr != null) isr.close();
                if (s != null) s.close();
            }
        }catch (IOException ex) {
            // In case of reading error print error on console and return "error"
            System.out.println(ex);
            return "error";
        }
    }

	/**
	 * Called once the user has correctly logged in.
	 * The server returns an arraylist of surveys related to the user.
	 * Two list of surveys are created: 
	 * 1. surveys: list of objects of the class Survey (the one visible by the client)
	 * 2. serverSurveys: list of objects of the class ServerSurvey (the one visible only 
	 * 	  by the server)
	 * @return the arraylist of surveys of the class Survey, related to the user
	 */
    public ArrayList<Survey> serverReadSurveys() {
		ArrayList<Survey> surveys = new ArrayList<>();
		serverSurveys = new ArrayList<>();
		ArrayList<Integer> alreadyVoted = new ArrayList<>();
        InputStreamReader isr = null;
        Scanner s = null;
		try{
			// Il the user is a voter
			if (role.equals("voter")){
				// Read the file of the surveys they have already voted and insert them in
				// the arraylist alreadyvoted
                try{
                    isr = new InputStreamReader(new FileInputStream("./server/voters/" + username + ".txt"), "UTF-8");
                    s = new Scanner(isr);
					String str;
					if (s.hasNextLine()){
						str = s.nextLine();
					}
                    while(s.hasNextLine()){
                        str = s.nextLine();
                        int num = Integer.parseInt(str);
                        int index = 0;
                        // Insertion sort: we create the arraylist alreadyVoted in such a way that it is sorted
                        for (int votedSurvey: alreadyVoted){
                            if(votedSurvey > num){
                                break;
                            }
                            index += 1;
                        }
                        alreadyVoted.add(index, num);
                    }
                }finally{
                    if (isr != null) isr.close();
                    if (s != null) s.close();
                }
            }
			// Read the list of surveys
			try{
				isr = new InputStreamReader(new FileInputStream("./server/surveys.txt"), "UTF-8");
				s = new Scanner(isr);
				numsurveys = 0;
				int index = 0;
				String str;
				if (s.hasNextLine()){
					str = s.nextLine();
				}
				while(s.hasNextLine()){
					numsurveys += 1;
					str = s.nextLine();
					int id = numsurveys;
					// A limit is imposed to read the spaces inside the title of the survey
					String[] info = str.split(" ", 2);
					String researcher = info[0];
					String title = info[1];
					ServerSurvey serverSurvey = new ServerSurvey(id, researcher, title);
					Survey survey = serverSurvey;
					// If the user is a researcher
					if (role.equals("researcher")){
						// If the survey belongs to the researcher
						if (username.equals(serverSurvey.getResearcher())){
							serverSurveys.add(serverSurvey); 
							surveys.add(survey);
						}
					}else{
						// If the survey is open and the user is a voter
						if(serverSurvey.getStatus()){
							// We remove from the list the surveys they already voted
							// AlreadyVoted is sorted, hence we can perform linear search on it
							while(index < alreadyVoted.size() && alreadyVoted.get(index) < id){
								index += 1;
							}
							if(index >= alreadyVoted.size() || alreadyVoted.get(index) != id){
								serverSurveys.add(serverSurvey);
								surveys.add(survey);
							}
						}
					}
				}
			}finally{
				if (isr != null) isr.close();
				if (s != null) s.close();
			}
		}catch (IOException ex) {
			// In case of reading error print error on console and return an empty output
			System.out.println(ex);
		}
		return surveys;
	}

	/**
	 * Called when a researcher has opened a new survey.
	 * Here the server adds the new survey to the array surveys and serverSurveys 
	 * and creates a new file for it
	 * @param title title of the new survey
	 * @param publicKey public key of the new survey
	 * @return the updated list of surveys related to the user
	 */
    public ArrayList<Survey> writeSurvey(String title, String publicKey) {
		ArrayList<Survey> surveys = new ArrayList<>();
        OutputStreamWriter osw = null;
        try{
			// Update the file containing the surveys
            try{
                osw = new OutputStreamWriter(new FileOutputStream("./server/surveys.txt", true), "UTF-8");
                osw.append("\n" + username + " " + title);
            }finally{
                if (osw != null) osw.close(); 
            }
			// Create a new file for the survey
            try{
				numsurveys += 1;
                osw = new OutputStreamWriter(new FileOutputStream("./server/surveys/" + numsurveys + ".txt", true), "UTF-8");
                osw.append("true" + "\n" + publicKey);
            }finally{
                if (osw != null) osw.close(); 
            }
        }catch (IOException ex) {
            // In case of reading error print error on console and return an empty output
            System.out.println(ex);
        }
		// Update the arraylists serverSurveys and surveys
		ServerSurvey serverSurvey = new ServerSurvey(numsurveys, username, title);
		serverSurveys.add(serverSurvey);
		for (ServerSurvey s: serverSurveys){
			Survey survey = s;
			surveys.add(survey);
		}
		return surveys;
    }

	/**
	 * Called when a researcher closes a survey, calling the method closeSurvey() of the 
	 * class ServerSurvey
	 * Mpreover, the server updates and returns the arraylist surveys
	 * @param id id of the survey that needs to be closed
	 * @return the updated list of surveys related to the user
	 */
	public ArrayList<Survey> serverCloseSurvey(int id){
		ArrayList<Survey> surveys = new ArrayList<>();
		// Search for the survey
		for (ServerSurvey s: serverSurveys){
			if (s.getId() == id){
				// Count votes and write on files the results
				s.closeSurvey();
				break;
			}
		}
		// Update the arraylist surveys
		for (ServerSurvey s: serverSurveys){
			Survey survey = s;
			surveys.add(survey);
		}
		return surveys;
	}

	/**
	 * Called when a voter has cast a vote for a survey.
	 * The server memorizes the vote through the method voteSurvey() of the class 
	 * ServerSurvey
	 * Moreover, the survey is removed from the arraylist serverSurveys, since the voter 
	 * cannot see it anymore, and the arraylist surveys is updated
	 * @param id id of the survey related to the vote
	 * @param encVote object of the class Vote, it is the vote that needs to be verified 
	 *        and eventually stored
	 * @return the updated list of surveys related to the user
	 */
	public ArrayList<Survey> serverVoteSurvey(int id, Vote encVote){
		ArrayList<Survey> surveys = new ArrayList<>();
		// Search for the survey
		for (ServerSurvey s: serverSurveys){
			if (s.getId() == id){
				// Verify vote
				boolean check = s.verifyVote(username, signPublicKey, encVote);
				if(check){
					// Write survey on file
					s.voteSurvey(encVote, "./server/voters/" + username + ".txt");
					serverSurveys.remove(s);
				}
				break;
			}
		}
		// Update the arraylist surveys
		for (ServerSurvey s: serverSurveys){
			Survey survey = s;
			surveys.add(survey);
		}
		return surveys;
	}
}
