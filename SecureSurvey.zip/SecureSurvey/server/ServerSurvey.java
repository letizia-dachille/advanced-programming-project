// Java utilities packages
import java.util.Scanner;
import java.io.*;
import java.math.BigInteger;
// Unicrypt library imports
import ch.bfh.unicrypt.crypto.proofsystem.challengegenerator.classes.FiatShamirSigmaChallengeGenerator;
import ch.bfh.unicrypt.crypto.proofsystem.challengegenerator.interfaces.SigmaChallengeGenerator;
import ch.bfh.unicrypt.crypto.proofsystem.classes.ElGamalEncryptionValidityProofSystem;
import ch.bfh.unicrypt.helper.math.Alphabet;
import ch.bfh.unicrypt.math.algebra.concatenative.classes.StringMonoid;
import ch.bfh.unicrypt.math.algebra.general.classes.*;
import ch.bfh.unicrypt.math.algebra.multiplicative.classes.GStarModElement;

/** Class that extends the class Survey. Here we add methods that are properly done by the server */
public class ServerSurvey extends Survey {
    // Main attributes definition
	private String path;

    /**
     * Public constructor of the class
     * @param id id of the survey
     * @param researcher username of the researcher that has created the survey
     * @param title title of the survey
     */
	public ServerSurvey(int id, String researcher, String title){
        super(id, researcher, title);
		this.path = "./server/surveys/" + id + ".txt";
        // Read the survey's file
        readSurvey();
    }

    /**
     * Called by the constructor of the class, reads the survey's file
     * @param path path of the survey file
     */
	public void readSurvey(){
		InputStreamReader isr = null;
        Scanner s = null;
        try{
            // Read the survey's file
            try{
                isr = new InputStreamReader(new FileInputStream(path), "UTF-8");
                s = new Scanner(isr);
				String str = s.nextLine();
				status = Boolean.valueOf(str);
                // If the survey is open
                if (status){
                    str = s.nextLine();
                    // Rebuild public key from the value in the file
                    publicKey = group.getElement(new BigInteger(str));
                    // Count number of votes of the survey
                    while(s.hasNextLine()){
                        s.nextLine();
                        numvotes++;
                    }
                }else{
					str = s.nextLine();
					String[] info = str.split(" ");
                    // Reading of the results (tot yes, tot no, tot abstain)
                    result[0] = Pair.getInstance(group.getElement(new BigInteger(info[0])), group.getElement(new BigInteger(info[1])));
                    result[1] = Pair.getInstance(group.getElement(new BigInteger(info[2])), group.getElement(new BigInteger(info[3])));
                    result[2] = Pair.getInstance(group.getElement(new BigInteger(info[4])), group.getElement(new BigInteger(info[5])));
				}
            }finally{
                if (isr != null) isr.close();
                if (s != null) s.close();
            }
        }catch (IOException ex) {
            // In case of reading error print error on console
            System.out.println(ex);
        }
	}

    /**
     * Called by the server in order to verify a vote with zero-knowledge proofs and 
     * signature.
     * @param username username of the voter, used to verify the zero-knowledge proof
     * @param signPublicKey public key of the voter, used to verify the signature
     * @param encVote object of the class Vote, it is the vote that needs to be verified
     * @return true if the check succeeds, false otherwise
     */
    public boolean verifyVote(String username, GStarModElement signPublicKey, Vote encVote){
        Pair[] ciphertexts = encVote.getCiphertexts();
        Triple[] proofs = encVote.getProofs();
        Triple proof = encVote.getProof();
        Tuple signature = encVote.getSignature();
        var encodedOne = generator.selfApply(1);
        var encodedZero = generator.selfApply(0);
        var impossibleElement = generator.selfApply(4);

        // Initialization of the proof system
        var proverId = StringMonoid.getInstance(Alphabet.BASE64).getElement(username);
        SigmaChallengeGenerator challengeGenerator = FiatShamirSigmaChallengeGenerator.getInstance(group.getZModOrder(), proverId);
        Subset subset = Subset.getInstance(group, encodedZero, encodedOne);
        ElGamalEncryptionValidityProofSystem proofSystem = ElGamalEncryptionValidityProofSystem.getInstance(challengeGenerator, elGamal, publicKey, subset);
        Subset subsetSum = Subset.getInstance(group, encodedOne, impossibleElement);
        ElGamalEncryptionValidityProofSystem proofSystemSum = ElGamalEncryptionValidityProofSystem.getInstance(challengeGenerator, elGamal, publicKey, subsetSum);

        // Verification
        Tuple encSum = ciphertexts[0].apply(ciphertexts[1].apply(ciphertexts[2]));
        String fullCiphertext = "";
        for (Pair ciphertext: ciphertexts){
            fullCiphertext += ciphertext.getFirst().getValue().toString() + ciphertext.getSecond().getValue().toString();
        }
        // The signature and four zk proofs are verified: one for each component of the 
        // vote and one for the sum of them
        return proofSystem.verify(proofs[0], ciphertexts[0]) && proofSystem.verify(proofs[1], ciphertexts[1]) && proofSystem.verify(proofs[2], ciphertexts[2]) && proofSystemSum.verify(proof, encSum) && schnorr.verify(signPublicKey, schnorr.getMessageSpace().getElement(fullCiphertext), signature).isTrue(); 
	}

    /**
     * Called by the server when a user has voted for a survey
     * Appends the vote to the survey's file and writes in personal file which surveys 
     * you already voted
     * @param encVote
     * @param userpath
     */
	public void voteSurvey(Vote encVote, String userpath){
        Pair[] ciphertexts = encVote.getCiphertexts();
        String stringVote = ciphertexts[0].getFirst().getValue().toString() + " " +
            ciphertexts[0].getSecond().getValue().toString() + " " +
            ciphertexts[1].getFirst().getValue().toString() + " " +
            ciphertexts[1].getSecond().getValue().toString() + " " +
            ciphertexts[2].getFirst().getValue().toString() + " " +
            ciphertexts[2].getSecond().getValue().toString();
		OutputStreamWriter osw = null;
        try{
            // Write in personal file which surveys you already voted
            try{
                osw = new OutputStreamWriter(new FileOutputStream(userpath, true), "UTF-8");
                osw.append("\n" + id);
            }finally{
                if (osw != null) osw.close(); 
            }
            // Append the vote to the survey's file
			try{
                osw = new OutputStreamWriter(new FileOutputStream(path, true), "UTF-8");
                osw.append("\n" + stringVote);
            }finally{
                if (osw != null) osw.close(); 
            }
        }catch (IOException ex) {
            // In case of reading error print error on console
            System.out.println(ex);
        }
	}

    /**
     * Called by the server when a researcher has closed a survey
     * The server tallies the votes and write results on the survey's file
     */
	public void closeSurvey(){
		status = false;
        Tuple totYes = null;
        Tuple totNo = null;
        Tuple totAbstain = null;
		InputStreamReader isr = null;
        Scanner s = null;
        try{
            // Read the votes from the survey's file
            try{
                isr = new InputStreamReader(new FileInputStream(path), "UTF-8");
                s = new Scanner(isr);
				String str = s.nextLine();
				str = s.nextLine();
                // Generate ciphertext of (0,0,0) to initialize the total sum
                var encodedZero = generator.selfApply(0);
                Pair encZero = elGamal.encrypt(publicKey, encodedZero);
                Pair encZero1 = elGamal.encrypt(publicKey, encodedZero);
                Pair encZero2 = elGamal.encrypt(publicKey, encodedZero);
                totYes = encZero;
                totNo = encZero1;
                totAbstain = encZero2;
                // Read each vote
                while(s.hasNextLine()){   
                    str = s.nextLine();
                    String[] info = str.split(" ");
                    // Reading of the results (tot yes, tot no, tot abstain)
                    Tuple encYes = Pair.getInstance(group.getElement(new BigInteger(info[0])), group.getElement(new BigInteger(info[1])));
                    Tuple encNo = Pair.getInstance(group.getElement(new BigInteger(info[2])), group.getElement(new BigInteger(info[3])));
                    Tuple encAbstain = Pair.getInstance(group.getElement(new BigInteger(info[4])), group.getElement(new BigInteger(info[5])));
                    // Update the total sum
                    totYes = totYes.apply(encYes);
                    totNo = totNo.apply(encNo);
                    totAbstain = totAbstain.apply(encAbstain);
                }
            }finally{
                if (isr != null) isr.close();
                if (s != null) s.close();
            }
        }catch (IOException ex) {
            // In case of reading error print error on console
            System.out.println(ex);
        }
        // Write the results as a string
        result[0] = totYes;
        result[1] = totNo;
        result[2] = totAbstain;
        String stringTotal = totYes.getAt(0).getValue().toString() + " " +
            totYes.getAt(1).getValue().toString() + " " +
            totNo.getAt(0).getValue().toString() + " " +
            totNo.getAt(1).getValue().toString() + " " +
            totAbstain.getAt(0).getValue().toString() + " " +
            totAbstain.getAt(1).getValue().toString();
		OutputStreamWriter osw = null;
        // Write the results in the survey's file
        try{
            try{
                osw = new OutputStreamWriter(new FileOutputStream(path), "UTF-8");
                osw.write(status + "\n" + stringTotal);
            }finally{
                if (osw != null) osw.close(); 
            }
        }catch (IOException ex) {
            // In case of reading error print error on console
            System.out.println(ex);
        }
	}

}