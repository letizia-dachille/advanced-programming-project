// Java utilities packages
import java.io.*;
import java.math.BigInteger;
import java.util.Scanner;
// Unicrypt library imports
import ch.bfh.unicrypt.crypto.schemes.encryption.classes.ElGamalEncryptionScheme;
import ch.bfh.unicrypt.crypto.schemes.signature.classes.SchnorrSignatureScheme;
import ch.bfh.unicrypt.helper.math.Alphabet;
import ch.bfh.unicrypt.helper.prime.SafePrime;
import ch.bfh.unicrypt.math.algebra.concatenative.classes.StringMonoid;
import ch.bfh.unicrypt.math.algebra.dualistic.classes.*;
import ch.bfh.unicrypt.math.algebra.general.classes.*;
import ch.bfh.unicrypt.math.algebra.multiplicative.classes.*;

/**
 * Class representing a survey with methods and attributes of a survey related to the
 * application side (client side)
 */
public class Survey {

    // Main attributes definition
    protected int id;
    protected String researcher;
    protected String title;
    protected boolean status;
    protected int numvotes = 0;
    protected Tuple[] result = new Pair[3];
    protected GStarModElement publicKey;
    // Public parameters of elgamal encryption scheme
    SafePrime safePrime = SafePrime.getInstance(new BigInteger("3952952178374640418685184644643708984074546024231724208070151738783263001877343589194283126064568671556054993913274656691266608028677124594822206814448069491672998261272213051291177598337250923016919856810019580253952209989658256703161738884745447892020055216615287652194338554628287069936110145818155328604534810095424963664114705686745495305052840776143931406780841441345247291460095883322441161433418652974157438099930479228013556776925727257771826809329604326695728044527371419345492855373804942166500544215272684440967470853540597382459478160044133807079579451508796628347553496488780847406551031849198721357471657010942640269179167074415651284916184657139734636221691799957857096887845722374764751301165724816790152735442699688944209717130091135675454795867014806599819715107283855486717011212372713268157823054092934109945546052453277746770135010661472066291976636681212590319367400517427424502915017501466270244564299"));
    GStarModSafePrime group = GStarModSafePrime.getInstance(safePrime);
    GStarModElement generator = group.getDefaultGenerator();
    ZMod order = generator.getSet().getZModOrder();
    ElGamalEncryptionScheme elGamal = ElGamalEncryptionScheme.getInstance(generator);
    // Public parameters of schnorr signature scheme
    SafePrime signSafePrime = SafePrime.getInstance(new BigInteger("5160289179960913922009630589553873386446241019346066584464789733730529820775975471558805071001746248628965281196631715655109211787623320097221593154021723397413011719734825864232550218292057819849916908621353330525916072743165961080647184413487006364873221639845813146666157485755176658930371463993970056677757245432617427952951731498672609884810444913435773165937698003676572685047604068221509587202023297212873219531499035553703317613901825962011464061665423331698093440057864951952119673263059442933268245837277755763504933073113278902151604780014211261994612488374092317481901995549233927884671313557525416210871791422878409622395862982552410160289950588703962692996276939322845431023867250713848696061595832893135813695573480799636518983135136110599909525694861264909900250864213944676652049701033110767457812408129043294318490225853306447730455615051514435305370888890407096401247663787658762826982331485609360468173807"));
    GStarModSafePrime signGroup = GStarModSafePrime.getInstance(signSafePrime);
    GStarModElement signGenerator = signGroup.getDefaultGenerator();
    ZMod signOrder = signGenerator.getSet().getZModOrder();
    @SuppressWarnings("unchecked")
    SchnorrSignatureScheme<StringMonoid> schnorr = SchnorrSignatureScheme.getInstance(StringMonoid.getInstance(Alphabet.BASE64), signGenerator);

    /**
     * Public constructor of the class
     * @param id id of the survey
     * @param researcher username of the researcher that has created the survey
     * @param title title of the survey
     */
    public Survey(int id, String researcher, String title){
        this.id = id;
        this.researcher = researcher;
        this.title = title;
    }

    /**
     * Id getter
     * @return the id of the survey
     */
    public int getId(){
        return id;
    }

    /**
     * Researcher getter
     * @return the username of the researcher that has created the survey
     */
    public String getResearcher(){
        return researcher;
    }

    /**
     * Title getter
     * @return the content of the survey
     */
    public String getTitle(){
        return title;
    }

    /**
     * Status getter
     * @return true if the survey is open, false otherwise
     */
    public boolean getStatus(){
        return status;
    }

    /**
     * Number of votes getter
     * @return the number of votes stored for this survey at the moment
     */
    public int getNumvotes(){
        return numvotes;
    }

    /**
     * Public key getter
     * @return the public key of this survey, it is used to encrypt votes for this survey
     */
    public GStarModElement getPublicKey(){
        return publicKey;
    }

    /**
     * Result getter: decrypts the results computed by the server
     * @return the results for this survey [numYes, numNo, numAbstain]
     */
	public int[] getResult(){
        ZModElement privateKey = null;
        InputStreamReader isr = null;
        Scanner s = null;
        // Recover the private key
		try{
			try{
				isr = new InputStreamReader(new FileInputStream("./researchers/" + researcher + ".txt"), "UTF-8");
				s = new Scanner(isr);
                String str;
                if (s.hasNextLine()){
                    str = s.nextLine();
                }
				while(s.hasNextLine()){
					str = s.nextLine();
					String[] info = str.split(" ");
					if (Integer.parseInt(info[0]) == id){
                        privateKey = order.getElement(new BigInteger(info[1]));
                    }
				}
			}finally{
				if (isr != null) isr.close();
				if (s != null) s.close();
			}
		}catch (IOException ex) {
			// In case of reading error print error on console
			System.out.println(ex);
		}
        // Decryption
        String decYes = elGamal.decrypt(privateKey, result[0]).getValue().toString();
        String decNo = elGamal.decrypt(privateKey, result[1]).getValue().toString();
        String decAbstain = elGamal.decrypt(privateKey, result[2]).getValue().toString();
        // Free variable containing private key and send object to garbage collector
        privateKey = null;
        System.gc();
        // Brute force on dlog to end the decryption phase
        int expYes = -1, expNo = -1, expAbstain = -1;
        do {
            expYes++;
        } while (!(generator.selfApply(expYes).getValue().toString().equals(decYes)));
        do {
            expNo++;
        } while (!(generator.selfApply(expNo).getValue().toString().equals(decNo)));
        do {
            expAbstain++;
        } while (!(generator.selfApply(expAbstain).getValue().toString().equals(decAbstain)));
        int[] decodedResult = {expYes, expNo, expAbstain};
        return decodedResult;
    }

    /**
     * Called when a researcher has opened a new survey.
     * The local files related to a new survey are created.
     * @param userpath path of the local file of the user
     * @param privateKey the private key related to the survey
     */
    public void writeSurvey(String userpath, String privateKey){
		OutputStreamWriter osw = null;
        // Write the id and the private key of the survey in the local file of the user
        try{
            try{
                osw = new OutputStreamWriter(new FileOutputStream(userpath, true), "UTF-8");
                osw.append("\n" + id + " " + privateKey);
            }finally{
                if (osw != null) osw.close(); 
            }
        }catch (IOException ex) {
            // In case of reading error print error on console
            System.out.println(ex);
        }
	}

    /**
     * Called when a voter has chosen to vote this survey.
     * Retrieves the private key of the voter for the signature.
     * @param userpath path of the local file of the user
     * @return the private key of the voter
     */
	public ZModElement voteSurvey(String userpath){
        ZModElement signPrivateKey = null;
        InputStreamReader isr = null;
        Scanner s = null;
        // Read from personal file the private key for signature
		try{
			try{
				isr = new InputStreamReader(new FileInputStream(userpath), "UTF-8");
				s = new Scanner(isr);
                String str = s.nextLine();
				String[] info = str.split(" ");
				signPrivateKey = signOrder.getElement(new BigInteger(info[0]));
			}finally{
				if (isr != null) isr.close();
				if (s != null) s.close();
			}
		}catch (IOException ex) {
			// In case of reading error print error on console and return an empty output
			System.out.println(ex);
		}
        return signPrivateKey;
	}
}
