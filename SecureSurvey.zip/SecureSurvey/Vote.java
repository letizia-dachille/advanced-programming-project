// Unicrypt library imports
import ch.bfh.unicrypt.math.algebra.general.classes.*;

/** Class used to implement a single encrypted vote */
public class Vote {
	// Main attributes definition
	private Pair[] ciphertexts = new Pair[3];
	private Triple[] proofs = new Triple[3];
	private Triple proofSum;
	private Tuple signature;

	/**
	 * Public constructor of the class
	 * @param ciphertexts encryption of the vote, array of three elements
	 * @param proofs array of the three zero knowledge proofs related to the three
	 *        elements of ciphertexts
	 * @param proofSum zero knowledge proof related to the sum of the three plaintexts
	 * @param signature signature of the vote through the private key of the voter
	 */
	public Vote(Pair[] ciphertexts, Triple[] proofs, Triple proofSum, Tuple signature){
		this.ciphertexts = ciphertexts;
		this.proofs = proofs;
		this.proofSum = proofSum;
		this.signature = signature;
	}

	/**
     * Ciphertexts getter
     * @return the ciphertexts encryption of the vote
     */
	public Pair[] getCiphertexts(){
		return ciphertexts;
	}

	/**
     * Proofs of plaintexts getter
     * @return the array of the three zero knowledge proofs related to the three
	 *         elements of ciphertexts
     */
	public Triple[] getProofs(){
		return proofs;
	}

    /**
     * Proof of sum getter
     * @return the zero knowledge proof related to the sum of the three plaintexts
     */
	public Triple getProof(){
		return proofSum;
	}

    /**
     * Signature getter
     * @return the signature of the vote through the private key of the voter
     */
	public Tuple getSignature(){
		return signature;
	}
} 